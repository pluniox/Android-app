package com.example.calculapp;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

import com.example.calculapp.database.CalculBaseHelper;
import com.example.calculapp.database.ScoreDao;
import com.example.calculapp.entities.GameScore;

public class SaveScoreActivity extends AppCompatActivity {
    private EditText nameEditText;
    private int score;
    private boolean isDifficultMode;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_save_score);

        nameEditText = findViewById(R.id.name_edit_text);

        score = getIntent().getIntExtra("score", 0);
        isDifficultMode = getIntent().getBooleanExtra("isDifficultMode", true);

        nameEditText.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_DONE ||
                    (event != null && event.getAction() == KeyEvent.ACTION_DOWN &&
                            event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                saveScore();
                return true;
            }
            return false;
        });

        findViewById(R.id.save_button).setOnClickListener(v -> saveScore());
    }

    private void saveScore() {
        String name = nameEditText.getText().toString().trim();
        if (!TextUtils.isEmpty(name)) {
            String mode = isDifficultMode ? "difficult" : "easy";
            GameScore scoreEntity = new GameScore(name, score, mode);
            CalculBaseHelper dbHelper = new CalculBaseHelper(this, "calcul_db", 1);
            ScoreDao scoreDao = new ScoreDao(dbHelper);
            scoreDao.create(scoreEntity);

            Intent intent = new Intent(SaveScoreActivity.this, MainActivity.class);
            startActivity(intent);
            finish();
        }
    }

}
