package com.example.calculapp;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import java.util.Random;

public class GameActivity extends AppCompatActivity {
    private int score = 0;
    private int lives = 3;
    private TextView scoreTextView;
    private TextView livesTextView;
    private TextView questionTextView;
    private EditText answerEditText;
    private int correctAnswer;
    private boolean isDifficultMode;
    private MenuItem scoreMenuItem;
    private MenuItem livesMenuItem;
    private TextView timerTextView;
    private CountDownTimer countDownTimer;
    private long timeLeftInMillis;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);

        EdgeToEdge.enable(this);

        questionTextView = findViewById(R.id.question_text_view);
        answerEditText = findViewById(R.id.answer_edit_text);
        timerTextView = findViewById(R.id.timer_text_view);
        Button submitButton = findViewById(R.id.submit_button);

        isDifficultMode = getIntent().getBooleanExtra("isDifficultMode", true);

        generateQuestion();
        startTimer();

        submitButton.setOnClickListener(v -> {
            checkAnswer();
        });

        answerEditText.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_DONE ||
                    (event.getAction() == KeyEvent.ACTION_DOWN &&
                            event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                checkAnswer();
                return true;
            }
            return false;
        });

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.toolbar_menu, menu);
        scoreMenuItem = menu.findItem(R.id.action_score);
        livesMenuItem = menu.findItem(R.id.action_lives);
        updateMenuItems();
        return true;
    }

    private void updateMenuItems() {
        String scoreTitle = getString(R.string.score_title, score);
        String livesTitle = getString(R.string.lives_title, lives);

        scoreMenuItem.setTitle(scoreTitle);
        livesMenuItem.setTitle(livesTitle);
    }

    private void generateQuestion() {
        int maxNumber = isDifficultMode ? 100 : 10;
        Random random = new Random();
        int a = random.nextInt(maxNumber);
        int b = random.nextInt(maxNumber);
        String[] operations = {"+", "-", "*"};
        String operation = operations[random.nextInt(operations.length)];
        answerEditText.setText("");

        String question;
        correctAnswer = 0;

        switch (operation) {
            case "+":
                correctAnswer = a + b;
                question = a + " + " + b;
                break;
            case "-":
                if (a < b) {
                    int temp = a;
                    a = b;
                    b = temp;
                }
                correctAnswer = a - b;
                question = a + " - " + b;
                break;
            case "*":
                correctAnswer = a * b;
                question = a + " * " + b;
                break;
            default:
                question = "";
                break;
        }

        questionTextView.setText(question);
    }

    private void checkAnswer() {
        String answer = answerEditText.getText().toString().trim();
        if (TextUtils.isEmpty(answer)) {
            return;
        }

        int userAnswer = Integer.parseInt(answer);

        if (userAnswer == correctAnswer) {
            score++;
        } else {
            lives--;
            if (lives <= 0) {
                endGame();
                return;
            }
        }

        updateMenuItems();
        generateQuestion();
        resetTimer();
        startTimer();
    }

    private void startTimer() {
        long timeInMillis;
        if (isDifficultMode) {
            timeInMillis = 60000;
        } else {
            timeInMillis = 15000;
        }

        countDownTimer = new CountDownTimer(timeInMillis, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                timeLeftInMillis = millisUntilFinished;
                updateTimerText();
            }

            @Override
            public void onFinish() {
                timeLeftInMillis = 0;
                lives--;
                updateMenuItems();
                if (lives <= 0) {
                    endGame();
                } else {
                    generateQuestion();
                    resetTimer();
                    startTimer();
                }
            }
        }.start();
    }

    private void updateTimerText() {
        int seconds = (int) (timeLeftInMillis / 1000);
        String timeText = getString(R.string.time_remainings, seconds);
        timerTextView.setText(timeText);
    }

    private void resetTimer() {
        if (countDownTimer != null) {
            countDownTimer.cancel();
        }
    }

    private void endGame() {
        Intent intent = new Intent(GameActivity.this, SaveScoreActivity.class);
        intent.putExtra("score", score);
        startActivity(intent);
        finish();
    }
}
