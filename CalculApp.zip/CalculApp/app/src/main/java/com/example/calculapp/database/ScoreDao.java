package com.example.calculapp.database;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.calculapp.entities.GameScore;

import java.util.ArrayList;
import java.util.List;

public class ScoreDao {
    public static final String tableName = "scores";
    public static final String columnName = "name";
    public static final String columnMode = "mode"; // Ajout du champ pour le mode de jeu
    public static final String columnScore = "score";

    private DataBaseHelper dbHelper;

    public ScoreDao(DataBaseHelper dbHelper) {
        this.dbHelper = dbHelper;
    }

    public void create(GameScore score) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(columnName, score.getName());
        values.put(columnScore, score.getScore());
        values.put(columnMode, score.getMode()); // Insérer le mode de jeu
        db.insert(tableName, null, values);
    }

    public List<GameScore> getScoresByMode(String mode) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        List<GameScore> scores = new ArrayList<>();

        Cursor cursor = db.query(
                tableName,
                null,
                columnMode + " = ?",
                new String[]{mode},
                null,
                null,
                "score DESC"
        );

        while (cursor.moveToNext()) {
            String name = cursor.getString(cursor.getColumnIndexOrThrow(columnName));
            int score = cursor.getInt(cursor.getColumnIndexOrThrow(columnScore));
            mode = cursor.getString(cursor.getColumnIndexOrThrow(columnMode));
            GameScore scoreEntity = new GameScore(name, score, mode);
            scores.add(scoreEntity);
        }

        cursor.close();
        return scores;
    }
}
