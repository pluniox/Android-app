package com.example.calculapp.entities;

public class GameScore extends BaseEntity {
    private final String name;
    private final int score;
    private String mode; // Nouveau champ pour le mode de jeu

    public GameScore(String name, int score, String mode) {
        this.name = name;
        this.score = score;
        this.mode = mode;
    }

    public String getName() {
        return name;
    }

    public int getScore() {
        return score;
    }

    public String getMode() {
        return mode;
    }
}
