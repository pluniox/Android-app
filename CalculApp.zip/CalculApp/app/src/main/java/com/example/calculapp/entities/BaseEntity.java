package com.example.calculapp.entities;

public abstract class BaseEntity {
    public long id;
}
