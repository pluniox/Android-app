package com.example.calculapp;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.calculapp.database.CalculBaseHelper;
import com.example.calculapp.database.ScoreDao;
import com.example.calculapp.entities.GameScore;

import java.util.List;

public class HighScoreActivity extends AppCompatActivity {
    private TextView easyHighScoresTextView;
    private TextView difficultHighScoresTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_high_score);

        easyHighScoresTextView = findViewById(R.id.easy_high_scores_text_view);
        difficultHighScoresTextView = findViewById(R.id.difficult_high_scores_text_view);

        displayHighScores();
    }

    private void displayHighScores() {
        ScoreDao scoreDao = new ScoreDao(new CalculBaseHelper(this, "calcul_db", 1));

        List<GameScore> easyScores = scoreDao.getScoresByMode("easy");
        if (!easyScores.isEmpty()) {
            StringBuilder easyScoresText = new StringBuilder();
            for (GameScore score : easyScores) {
                easyScoresText.append(score.getName()).append(": ").append(score.getScore()).append("\n");
            }
            easyHighScoresTextView.setText(easyScoresText.toString());
        } else {
            easyHighScoresTextView.setText(getString(R.string.no_scores_easy));
        }

        List<GameScore> difficultScores = scoreDao.getScoresByMode("difficult");
        if (!difficultScores.isEmpty()) {
            StringBuilder difficultScoresText = new StringBuilder();
            for (GameScore score : difficultScores) {
                difficultScoresText.append(score.getName()).append(": ").append(score.getScore()).append("\n");
            }
            difficultHighScoresTextView.setText(difficultScoresText.toString());
        } else {
            difficultHighScoresTextView.setText(getString(R.string.no_scores_difficult));
        }
    }
}
