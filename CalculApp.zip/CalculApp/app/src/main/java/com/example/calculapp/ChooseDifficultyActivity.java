package com.example.calculapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import androidx.appcompat.app.AppCompatActivity;

public class ChooseDifficultyActivity extends AppCompatActivity {
    private RadioGroup difficultyRadioGroup;
    private Button startGameButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choose_difficulty);

        difficultyRadioGroup = findViewById(R.id.difficulty_radio_group);
        startGameButton = findViewById(R.id.start_game_button);

        startGameButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int checkedId = difficultyRadioGroup.getCheckedRadioButtonId();
                RadioButton radioButton = findViewById(checkedId);

                boolean isDifficultMode = radioButton.getId() == R.id.difficult_radio_button;

                Intent intent = new Intent(ChooseDifficultyActivity.this, GameActivity.class);
                intent.putExtra("isDifficultMode", isDifficultMode);
                startActivity(intent);
            }
        });
    }
}
