package com.example.calculapp.database;

import android.content.Context;

public class CalculBaseHelper extends DataBaseHelper {
    public CalculBaseHelper(Context context, String dataBaseName, int dataBaseVersion) {
        super(context, dataBaseName, dataBaseVersion);
    }
    public CalculBaseHelper(Context context) {
        super(context, "calcul_db", 1);
    }

    @Override
    protected String getCreationSql() {
        return "CREATE TABLE IF NOT EXISTS " + ScoreDao.tableName + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                ScoreDao.columnName + " TEXT NOT NULL," +
                ScoreDao.columnScore + " INTEGER NOT NULL," +
                ScoreDao.columnMode + " TEXT NOT NULL" +
                ")";
    }


    @Override
    protected String getDeleteSql() {
        return "DROP TABLE IF EXISTS " + ScoreDao.tableName;
    }
}
